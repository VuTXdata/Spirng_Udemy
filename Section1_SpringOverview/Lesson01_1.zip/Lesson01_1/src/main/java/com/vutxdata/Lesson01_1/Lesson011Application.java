package com.vutxdata.Lesson01_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson011Application {

	public static void main(String[] args) {
		SpringApplication.run(Lesson011Application.class, args);
	}

}
