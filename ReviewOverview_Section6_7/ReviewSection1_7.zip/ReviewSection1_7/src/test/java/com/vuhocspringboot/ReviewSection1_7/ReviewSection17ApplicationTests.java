package com.vuhocspringboot.ReviewSection1_7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewSection17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
