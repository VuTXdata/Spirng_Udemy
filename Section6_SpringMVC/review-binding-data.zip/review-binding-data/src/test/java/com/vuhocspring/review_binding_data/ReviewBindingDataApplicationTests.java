package com.vuhocspring.review_binding_data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewBindingDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
