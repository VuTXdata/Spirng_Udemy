package com.vuhocspringboot.springboot_crud_mvc_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudMvcSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
