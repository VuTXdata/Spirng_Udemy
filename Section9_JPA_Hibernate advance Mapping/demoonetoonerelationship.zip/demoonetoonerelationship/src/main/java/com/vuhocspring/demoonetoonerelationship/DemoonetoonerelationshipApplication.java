package com.vuhocspring.demoonetoonerelationship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoonetoonerelationshipApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoonetoonerelationshipApplication.class, args);
	}

}
