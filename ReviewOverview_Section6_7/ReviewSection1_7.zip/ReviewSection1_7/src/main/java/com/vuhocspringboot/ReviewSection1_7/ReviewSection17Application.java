package com.vuhocspringboot.ReviewSection1_7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewSection17Application {

	public static void main(String[] args) {
		SpringApplication.run(ReviewSection17Application.class, args);
	}

}
