package com.vuhocspring.review_binding_data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewBindingDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewBindingDataApplication.class, args);
	}

}
