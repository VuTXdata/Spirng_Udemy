package com.vuhocspring.validated_data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidatedDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidatedDataApplication.class, args);
	}

}
